﻿namespace temetryapi.Controllers
{
    public interface IHttpActionResult
    {
    }
}